# CentOS 7 to AlmaLinux 8 Migration Toolkit

## ⚠️ CRITICAL WARNINGS

1. **ALWAYS BACKUP EVERYTHING BEFORE PROCEEDING**
2. **Test in a staging environment first if possible**
3. **CentOS 7 is EOL - security risk increases daily**
4. **Schedule maintenance window - expect 2-8 hours downtime**

## Your Current Setup

- CentOS Linux 7.9.2009 (EOL)
- Kernel: 3.10.0-1160.119.1.el7.x86_64
- Services: Webmin, Virtualmin, Apache, Mail Server, MariaDB

## Migration Options

### Option 1: ELevate In-Place Upgrade (Risky for Production)
Uses AlmaLinux's ELevate project to upgrade in-place.
- **Pros**: Keeps current server, less data movement
- **Cons**: Higher risk of issues, may break Virtualmin

### Option 2: Fresh AlmaLinux 8 + Virtualmin Migration (RECOMMENDED)
New server with fresh install, migrate using Virtualmin backups.
- **Pros**: Clean system, lowest risk, easy rollback
- **Cons**: Requires second server/IP temporarily

### Option 3: Manual Migration
Export/import all data manually.
- **Pros**: Full control
- **Cons**: Time-consuming, error-prone

## Scripts Included

1. `01-pre-migration-audit.sh` - Audit current system
2. `02-full-backup.sh` - Complete backup of all data
3. `03-virtualmin-backup.sh` - Virtualmin-specific backups
4. `04-elevate-upgrade.sh` - In-place upgrade via ELevate
5. `05-new-server-setup.sh` - Fresh AlmaLinux 8 setup
6. `06-restore-migration.sh` - Restore data to new server
7. `07-post-migration-verify.sh` - Verify migration success

## Recommended Migration Path

```
┌─────────────────────────────────────────────────────────────┐
│  PHASE 1: PREPARATION (Current CentOS 7 Server)            │
├─────────────────────────────────────────────────────────────┤
│  1. Run 01-pre-migration-audit.sh                          │
│  2. Run 02-full-backup.sh                                  │
│  3. Run 03-virtualmin-backup.sh                            │
│  4. Copy all backups to external storage                   │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  PHASE 2: NEW SERVER SETUP                                 │
├─────────────────────────────────────────────────────────────┤
│  1. Provision new AlmaLinux 8 server                       │
│  2. Run 05-new-server-setup.sh                             │
│  3. Transfer backups to new server                         │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  PHASE 3: MIGRATION                                        │
├─────────────────────────────────────────────────────────────┤
│  1. Run 06-restore-migration.sh                            │
│  2. Run 07-post-migration-verify.sh                        │
│  3. Update DNS to point to new server                      │
│  4. Monitor for 24-48 hours                                │
│  5. Decommission old server                                │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# On CentOS 7 server - run as root
chmod +x *.sh
./01-pre-migration-audit.sh
# Review output, then proceed with backups
./02-full-backup.sh
./03-virtualmin-backup.sh
```

## Support

If issues arise:
- AlmaLinux Forums: https://forums.almalinux.org/
- Virtualmin Forums: https://forum.virtualmin.com/
- ELevate Documentation: https://wiki.almalinux.org/elevate/
